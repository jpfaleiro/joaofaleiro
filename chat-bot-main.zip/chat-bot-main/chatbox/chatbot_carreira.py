from flask import Flask, request, jsonify
from flask_cors import CORS
import google.generativeai as genai
import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("API_KEY")

if not API_KEY:
    raise RuntimeError(
        "API_KEY não encontrada. Crie um arquivo .env com API_KEY=<sua_chave> "
        "ou descomente o fallback no código para testes."
    )

genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("gemini-1.5-flash")

app = Flask(__name__)
CORS(app)

@app.route("/chat", methods=["POST"])
def chat():
    try:        
        data = request.get_json(silent=True)
        if not data:
            data = request.form.to_dict()

        user_message = (data.get("message") or "").strip()
        if not user_message:
            return jsonify({"error": "Campo 'message' é obrigatório."}), 400

        prompt = f"""
Você é consultor de carreira em TI apenas se te pedirem algo relacionado a TI, caso contrário responda normal. Responda de forma curta, clara e acionável.

REGRAS:
- Máximo 120 palavras.
- Use no máximo 5 itens numerados (1–5), 1 frase por item, apenas em duvidas que exijam isso.
- Sem introdução ou conclusão; sem repetições.
- Foque em ações práticas adaptadas ao contexto.
- Não coloque nada entre *** ou algo do tipo.

Contexto do usuário: "{user_message}"

FORMATO DE SAÍDA:
1) ...
2) ...
3) ...
4) ...
5) ...
"""

        response = model.generate_content(prompt)
        reply = (getattr(response, "text", "") or "").strip()

        if not reply:
            print("[AVISO] Resposta vazia do modelo. Response:", response)
            return jsonify({"reply": "Não consegui gerar uma resposta agora. Tente novamente."}), 502

        return jsonify({"reply": reply})

    except Exception as e:
        print(f"[ERRO] /chat: {e}")
        return jsonify({"reply": "Desculpe, não consegui processar sua pergunta agora. Tente novamente."}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
