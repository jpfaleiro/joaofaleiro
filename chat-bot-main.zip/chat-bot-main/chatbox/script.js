const API_URL = "http://localhost:5000/chat";

const messagesEl = document.getElementById("messages");
const form = document.getElementById("chat-form");
const input = document.getElementById("msg");
const sendBtn = document.getElementById("send");
const tpl = document.getElementById("tpl-msg");

function nowStr(){
  const d = new Date();
  return d.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"});
}

function addBubble(text, who){
  const node = tpl.content.firstElementChild.cloneNode(true);
  node.classList.add(who === "user" ? "user" : "bot");
  node.querySelector(".bubble__content").textContent = text;
  node.querySelector(".bubble__time").textContent = nowStr();
  messagesEl.appendChild(node);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return node;
}

function addTyping(){
  const node = tpl.content.firstElementChild.cloneNode(true);
  node.classList.add("bot");
  const content = node.querySelector(".bubble__content");
  content.innerHTML = `
    <span class="typing">
      <span class="typing__dot"></span>
      <span class="typing__dot"></span>
      <span class="typing__dot"></span>
    </span>`;
  node.querySelector(".bubble__time").textContent = "digitando…";
  messagesEl.appendChild(node);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return node;
}

function autoResizeTextarea(el){
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 160) + "px";
}
input.addEventListener("input", () => autoResizeTextarea(input));

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;

  addBubble(text, "user");
  input.value = "";
  autoResizeTextarea(input);
  input.disabled = true;
  sendBtn.disabled = true;

  const typing = addTyping();

  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text })
    });

    let data = {};
    try { data = await res.json(); } catch {}

    if (!res.ok) {
      const msg = data?.error || data?.reply || `Erro HTTP ${res.status}`;
      throw new Error(msg);
    }

    typing.remove();
    addBubble(data.reply || "(resposta vazia)", "bot");
  } catch (err) {
    console.error(err);
    typing.remove();
    addBubble("Ops! Não consegui responder agora. Verifique se o servidor está rodando em http://localhost:5000 e tente novamente.", "bot");
  } finally {
    input.disabled = false;
    sendBtn.disabled = false;
    input.focus();
  }
});

input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});

const widget = document.getElementById("chat-widget");
const launcher = document.getElementById("chat-launcher");
const badge = document.querySelector(".chat-launcher__badge");
let unread = 0;

function openWidget(){
  widget.classList.remove("is-hidden");
  widget.setAttribute("aria-hidden", "false");
  launcher.setAttribute("aria-expanded", "true");
  setTimeout(() => input?.focus(), 50);
  unread = 0;
  if (badge) { badge.textContent = "0"; badge.hidden = true; }
}

function closeWidget(){
  widget.classList.add("is-hidden");
  widget.setAttribute("aria-hidden", "true");
  launcher.setAttribute("aria-expanded", "false");
}

launcher.addEventListener("click", () => {
  const isHidden = widget.classList.contains("is-hidden");
  isHidden ? openWidget() : closeWidget();
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !widget.classList.contains("is-hidden")) {
    closeWidget();
  }
});

document.addEventListener("pointerdown", (e) => {
  if (widget.classList.contains("is-hidden")) return;
  const clickInsideWidget = widget.contains(e.target);
  const clickOnLauncher = launcher.contains(e.target);
  if (!clickInsideWidget && !clickOnLauncher) closeWidget();
});

const _addBubble = addBubble; 
window.addBubble = function(text, who){
  const node = _addBubble(text, who);
  if (who !== "user" && widget.classList.contains("is-hidden")) {
    unread = Math.min(unread + 1, 99);
    if (badge) { badge.textContent = String(unread); badge.hidden = false; }
  }
  return node;
};

